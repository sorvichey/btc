@extends('layouts.front')
@section('content')
    <link href="{{asset('front/css/page.css')}}" rel="stylesheet">
    <!-- ***** Contact Us Area Start ***** -->
    <section class="footer-contact-area section_padding_100 clearfix" id="contact">
        <div class="container">
            <h2 class="text-white">Payment Request</h2>
        </div>
    </section>
    <section>
        <div class="container" style="margin-top: 54px">
           <h3 class="text-success">
               Thanks for your payment request. We are processing and will get back to you soon!
           </h3>
        </div>
        <p>&nbsp;</p>
        <hr>
        <p>&nbsp;</p>
    </section>

@endsection