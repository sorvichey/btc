@extends('layouts.front')
@section('content')
<section class="pricing-plane-area page-plan section_padding_100_90 clearfix" id="pricing">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="section-heading text-center">
                    <h2 class="text-plan text-white">Selecting A Plan</h2>
                    <div class="line-shape"></div>
                </div>
            </div>
        </div>
       
    </div>
</section>
<section>
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <p></p>
                <h4 class="text-success text-center">
                        Thanks for your order. Please wait, we are processing your order. We will get back to you soon!
                </h4>
            </div>
        </div>
        <div class="row">
            &nbsp;
        </div>
    </div>
</section>
@endsection